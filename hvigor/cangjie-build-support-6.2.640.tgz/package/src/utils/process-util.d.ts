/// <reference types="node" />
import { type SpawnOptionsWithoutStdio, type SpawnSyncOptions } from 'child_process';
import { LogCombineType } from '@ohos/hvigor-ohos-plugin/src/utils/log/log-combine-type';
import type { BooleanCallback } from '@ohos/hvigor-ohos-plugin/src/common/type/callback-type';
/**
 * Tool class for executing commands.
 *
 * @since 2024-01-14
 */
export declare class ProcessUtil {
    private _log;
    private readonly _moduleName;
    private readonly _taskName;
    private readonly _errLog;
    private readonly _ohosCharset;
    private readonly _solution;
    private readonly _defaultOptions;
    constructor(moduleName?: string, taskName?: string, errLog?: string, solution?: string, charset?: string);
    private static makeError;
    execute(executeOptions: ExecuteOptions): Promise<string>;
    /**
     * Input Parameter options Required for Generating execa
     *
     * @param options - Input parameters
     */
    processOptionsFactory(options: SpawnSyncOptions | undefined | SpawnOptionsWithoutStdio): SpawnSyncOptions;
    private handleException;
    private validateExecuteFile;
    private setupProcessFailHandler;
    private killProcess;
    private handleProcessCompletion;
    private handleStdout;
    private processStderr;
    private extractErrors;
    private addFoldContent;
    private decodeStderr;
    private handleSuccessfulCompletion;
}
interface ExecuteOptions {
    command: string[];
    options?: SpawnSyncOptions;
    filterMsgs?: RegExp[];
    combine?: LogCombineType;
    specialLogCallBack?: BooleanCallback;
}
export {};
