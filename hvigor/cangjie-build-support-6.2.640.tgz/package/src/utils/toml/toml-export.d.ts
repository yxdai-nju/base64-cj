/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { CustomTomlTypes } from './toml-types';
export declare class TOML {
    private codeDocMap;
    parse(content: string): Record<string, CustomTomlTypes>;
    stringify(obj: unknown): string;
}
