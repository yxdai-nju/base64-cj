export declare function getHomedir(): string | null;
