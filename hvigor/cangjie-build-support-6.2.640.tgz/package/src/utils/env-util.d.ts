/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */
/// <reference types="node" />
import { ProjectModel } from '@ohos/hvigor-ohos-plugin/src/model/project/project-model';
export declare function configOhModulesEnv(projectModel: ProjectModel, env: NodeJS.ProcessEnv): void;
export declare function configLocalModulesEnv(projectModel: ProjectModel, env: NodeJS.ProcessEnv): void;
