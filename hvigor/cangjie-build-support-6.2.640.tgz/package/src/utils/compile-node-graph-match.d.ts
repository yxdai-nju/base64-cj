/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */
import { ProjectModel } from '@ohos/hvigor-ohos-plugin/src/model/project/project-model';
/**
 * Analyze the compilation path of Cangjie.
 *
 * @since 2025/11/26
 */
export declare class CompileNodeGraphMatch {
    private static instance;
    private tdtuLog;
    private _mode;
    private dependsEnv;
    private _tomlTreeMap;
    private _moduleTomlNameMap;
    private _roots;
    private _startPackageTasks;
    private moduleTargets;
    get mode(): string;
    get tomlTreeMap(): Map<string, TomlTreeNode>;
    get moduleTomlNameMap(): Map<string, string>;
    get roots(): Set<string>;
    get startPackageTasks(): Set<string>;
    static getInstance(): CompileNodeGraphMatch;
    /**
     * 从所有模块入口构建唯一的依赖树集合
     *
     * @param {ProjectModel} projectModel
     */
    buildUniqueDependencyTrees(projectModel: ProjectModel): void;
    /**
     * 收集该节点所有祖先节点的 moduleTargets
     *
     * @param key Map 中的键 tomlName
     * @returns 所有收集到的 moduleTargets 集合
     */
    collectParentModuleTargets(key: string): Set<string>;
    /**
     * 迭代收集指定任务下的所有打包任务 (使用 DFS)
     *
     * @param startTask 起始任务名称
     */
    getPackageTasks(startTask: string): void;
    /**
     * 从起始节点触发，检查：
     * 1. 是否能到达目标节点
     * 2. 在遍历子节点是否经过任意一个祖先节点
     *
     * @param {string} startNode 起始节点
     * @param {string} targetNode 目标节点
     * @param {Set<string>} ancestorNodes 祖先节点集合
     * @returns {boolean} 是否同时满足上述两个条件
     */
    hasPathToNode(startNode: string, targetNode: string, ancestorNodes: Set<string>): boolean;
    private initBuildStartTasks;
    private getSpecifiedModules;
    private initTomlDependenciesTree;
    private initRootTasks;
    private collectCompileCangjieTask;
    private getDependencies;
    private generateModuleTargets;
    /**
     * 拼接module name和task name
     *
     * @param {string} moduleName 如果是project则为“”,如果是module则是moduleName
     * @param {string} taskName taskName
     * @returns {string} taskPath
     */
    private union;
}
/**
 * 表示依赖树中的一个节点
 */
declare class TomlTreeNode {
    tomlName: string;
    tomlPath: string;
    moduleTargets: string[];
    children: Set<TomlTreeNode>;
    parent: TomlTreeNode | undefined;
    constructor(tomlName: string, tomlPath: string);
    /**
     * 用于在Set中进行去重比较的方法
     */
    equals(other: TomlTreeNode): boolean;
}
export {};
