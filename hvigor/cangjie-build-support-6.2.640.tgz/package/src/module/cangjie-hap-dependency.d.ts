/**
 * cangjie dependent dynamic library collection
 *
 * @since 2024/1/6
 */
export declare class CangjieHapDependency {
    private _log;
    private includedModules;
    private existed;
    private readonly abi;
    private dependenciesMap;
    private readonly dependsEnv;
    constructor(abi: string, dependsEnv: any);
    getTargetRequires(moduleTomlData: any, workspacePath: string, excludeFiles: string[]): void;
    getPackageRequires(moduleData: any, workspacePath: string, excludeFiles: string[]): void;
    getForeignCRequires(moduleTomlData: any, workspacePath: string): void;
    getDependencies(moduleData: any, workspacePath: string, excludeFiles: string[]): void;
    doFindAllDependencies(workspacePathUriParam: string, excludeFiles: string[]): void;
    getPathByLockFile(workspacePath: string, moduleName: string): string;
    doCopyCompileLibs(folderPath: string, parentFolder: string, isFilter: boolean, destPath: string, isHar: boolean): Promise<void>;
    doCopyDependencies(buildOutputDir: string, isHarModule: boolean): Promise<void>;
    private copyLibFiles;
    private addDependencies;
    private getRequires;
}
