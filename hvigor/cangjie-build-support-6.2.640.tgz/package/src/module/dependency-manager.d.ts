import type { PackageJson } from 'type-fest';
import type { ModuleModel } from '@ohos/hvigor-ohos-plugin/src/model/module/module-model';
import type { ProjectModel } from '@ohos/hvigor-ohos-plugin/src/model/project/project-model';
export declare type OhosPackageJson = PackageJson & {
    ohos?: {
        org: string;
        artifactType: string;
    };
    artifactType?: string;
};
/**
 * 管理har的依赖，提供获取当前模块依赖的数据信息
 *
 * @since 2024/6/26
 */
export declare class DependencyManager {
    private _allDependency;
    private readonly _model;
    private readonly _projectModel;
    private readonly _moduleName;
    private readonly _isFaMode;
    private readonly _isOhpmDependency;
    constructor(isFaMode: boolean, model: ModuleModel | ProjectModel, project?: ProjectModel);
    checkModelDependencyInfo(): void;
    private isOhpmDependency;
    private collectHarDependency;
    private collectDependency;
    private isDynamicDepend;
    private isNeedCollect;
    /**
     * 通过config.json/module.json5判断当前模块是否为鸿蒙依赖（har/hsp）
     *
     * @param {string} pkgPath 当前模块的路径
     * @returns {boolean}
     * @private
     */
    private getDependencyTypeByProfile;
    /**
     * 检查当前模块的moduleType是否标记为har或hsp，且model与hap是否一致
     *
     * @param {string} runtimeJson config.json/module.json5
     * @param {boolean} harIsFAMode har包是否为FA model
     * @returns {boolean}
     * @private
     */
    private checkHarOrHspStatus;
    private getDependencyType;
    /**
     * 1. 根据config.json/module.json5判断是不是鸿蒙依赖（har/hsp）
     * 2. 根据包管理的关键特征判断是否是har报
     * 3. 考虑循环依赖，用set过滤重复项，向queue中添加package.json路径
     *
     * @param {string} pkgJsonPath 当前模块依赖的npm的package.json/oh-package.json5路径
     * @param {OhosPackageJson} devPkgJsonObj 当前模块依赖的package.json对象
     * @param curPkgJsonPath
     * @param pkgName
     * @returns {boolean}
     * @private
     */
    private getHarmonyDependencyType;
    /**
     * npm和ohpm的不同包管理机制下,判断一个依赖是否为har包
     * 1.ohpm只需要判断依赖中是否包含oh-package.json5
     * 2.npm需要判断package.json5中是否包含ohos字段
     *
     * @param {string} pkgPath
     * @param {OhosPackageJson} devPkgJsonPathObj
     * @returns {boolean}
     * @private
     */
    private isHarForDiffPackManagement;
    private getSODependencyType;
}
