import { ModulePathInfoIml } from '@ohos/hvigor-ohos-plugin/src/common/iml/module-path-info-iml';
/**
 * Cangjie Common Path
 *
 * @since 2024/8/1
 */
export declare class CangjieCommonPath {
    protected readonly _targetName: string;
    protected readonly _modulePathInfo: ModulePathInfoIml;
    protected readonly _abi: string;
    protected _buildMode: string;
    protected _mockPath: string;
    constructor(targetName: string, modulePathInfo: ModulePathInfoIml, abi?: string, customCjpmArgs?: string[]);
    get abi(): string;
    get buildMode(): string;
    get mockPath(): string;
    set mockPath(value: string);
    getIntermediatesCjBuild(): string;
    getIntermediatesCjpmHistory(): string;
    getIntermediatesCjBuildTarget(): string;
    getIntermediatesCjBuildMacroRelease(): string;
    getIntermediatesCjBuildRelease(): string;
    getIntermediatesCjBuildLogRelease(): string;
    getIntermediatesUnitTestBin(): string;
    getIntermediatesCjLibsRoot(): string;
    getIntermediatesCjLibs(): string;
    getIntermediatesCjLibsAbi(): string;
    getIntermediatesCjCompileLibs(): string;
    getIntermediatesCjUnitLibs(): string;
    getIntermediatesCjOhosLibs(): string;
    getIntermediatesCjRuntimeLibs(): string;
    getIntermediatesCjBinLibs(): string;
    getIntermediatesCjAsanLibs(): string;
    getIntermediatesProcessLibs(): string;
    getIntermediatesProcessCompileLibs(): string;
    getIntermediatesProcessBinLibs(): string;
    getIntermediatesProcessOhosLibs(): string;
    getIntermediatesProcessRuntimeLibs(): string;
    getIntermediatesProcessAsanLibs(): string;
    getIntermediatesStrippedLibs(): string;
    getIntermediatesStrippedOhosLibs(): string;
    getIntermediatesStrippedRuntimeLibs(): string;
    getIntermediatesStrippedBinLibs(): string;
    getExtendLibPath(isHarModule: boolean): string;
    getRuntimeOutLibPath(asanEnabled: boolean, isHarModule: boolean): string;
}
