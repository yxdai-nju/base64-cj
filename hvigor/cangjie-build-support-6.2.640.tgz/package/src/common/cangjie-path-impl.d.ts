/// <reference types="node" />
import { ModulePathInfoIml } from '@ohos/hvigor-ohos-plugin/src/common/iml/module-path-info-iml';
import { SdkCangjieComponent } from '../sdk/sdk-cangjie-component';
import { CangjieCommonPath } from './cangjie-common-path';
/**
 * Cangjie Path Info
 *
 * @since 2024/8/1
 */
export declare class CangjiePathImpl extends CangjieCommonPath {
    private readonly _sdkComponent;
    private implLogger;
    constructor(targetName: string, modulePathInfo: ModulePathInfoIml, abi: string, sdkComponent: SdkCangjieComponent, customCjpmArguments: string[]);
    getRuntimeOhosPathByAbi(): string;
    getOhosLibsPathByAbi(): string;
    getKitLibsPathByAbi(): string;
    getAsanRuntimeLibsPathByAbi(): string;
    getBuildEnvByAbi(tpcPath: string): NodeJS.ProcessEnv;
    getTpcEnvPathByAbi(tpcPath: string): NodeJS.ProcessEnv;
    getOtherConfigEnvs(): NodeJS.ProcessEnv;
    getWrapperMockPathByAbi(): string;
    getWrapperDiffPathByAbi(): string;
    getApiMockPathByAbi(): string;
    getApiCompatibilityByAbi(): string;
    getApiCompatiblePathByAbi(): string;
    getRuntimeCompatibilityPathByAbi(): string;
    getRuntimeMockPathByAbi(): string;
    getEscapeWrapperMockPathByAbi(): string;
    getEscapeWrapperDiffPathByAbi(): string;
    getEscapeApiMockPathByAbi(): string;
    getEscapeRuntimeMockPathByAbi(): string;
}
