import { ModuleJson } from '@ohos/hvigor-ohos-plugin/src/options/configure/module-json-options';
import { OhosLogger } from '@ohos/hvigor-ohos-plugin/src/utils/log/ohos-logger';
import { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { PreBuild } from '@ohos/hvigor-ohos-plugin/src/tasks/pre-build';
import { FileSet } from '@ohos/hvigor';
/**
 * preBuild Task
 *
 * @since 2022/1/10
 */
export declare class CangjiePreBuild extends PreBuild {
    private readonly supportDevices;
    private readonly versionPrefixLength;
    private readonly checkCompatibleVersions;
    constructor(taskService: TargetTaskService);
    declareInputFiles(): FileSet;
    /**
     * 检查所有srcEntry字段是否以相对路径的形式配置
     * @private
     */
    protected checkAllSrcEntry(): void;
    protected checkSrcEntry(obj2srcEntryListMap: Map<string, string[]>): void;
    protected validateModuleSrcEntry(logger: OhosLogger, moduleJsonObj: ModuleJson.ModuleOptObj): void;
    protected checkVersions(): void;
    protected checkCangjieDeviceTypes(isOhosTest: boolean): void;
    protected checkAbiFilters(): void;
    protected checkCjSourceDir(cangjieOptionPath: string, profileFile: string): void;
    private getCangjieRootPackage;
    private getExtensionAbilities;
    private getConfigAbilities;
    private getConfigSrcEntry;
    private checkCangjieEntry;
    private checkCangjieHsp;
    private checkDependenciesMatches;
    private checkDefaultDepends;
    private checkEscapeDepends;
    private isOhpmDependency;
}
