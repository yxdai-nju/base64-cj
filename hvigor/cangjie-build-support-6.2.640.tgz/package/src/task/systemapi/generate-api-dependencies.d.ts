import { AbstractModuleHookTask } from '@ohos/hvigor-ohos-plugin/src/tasks/hook/abstract-module-hook-task';
import type { ModuleTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/module-task-service';
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
/**
 * generate api dependencies
 *
 * @since 2024/12/16
 */
export declare class GenerateApiDependencies extends AbstractModuleHookTask {
    constructor(moduleTaskService: ModuleTaskService);
    initTaskDepends(taskTargetService: TargetTaskService): void;
}
