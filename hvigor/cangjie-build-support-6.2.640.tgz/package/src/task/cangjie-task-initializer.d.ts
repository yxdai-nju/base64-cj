/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import { GlobalTaskCreator, TargetTaskCreator } from '@ohos/hvigor-ohos-plugin/src/tasks/task-creator';
import type { CoreTask, TaskDetails } from '@ohos/hvigor';
import { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
export declare class CangjiePreBuildCA extends TargetTaskCreator {
    provider: () => CoreTask;
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    afterConfigure: () => void;
}
export declare class GenerateCangjieResourceCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class PreviewGenerateCangjieResourceCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class CompileCangjieCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class ProcessCangjieLibsCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class AfterCompileCangjieCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class MoveCangjieLibsCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class SyncCangjieResourceCA extends GlobalTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class GenerateCangjieInteropApiCA extends GlobalTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class CompileCangjieForIdlCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class GenerateTomlDependenciesCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class BeforeProcessLibsCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class AddApiDependenciesCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class GenerateApiDependenciesCA extends GlobalTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare class UnitTestCompileCangjieCA extends TargetTaskCreator {
    declareDepends: () => string[];
    declareTaskDetail: () => TaskDetails;
    provider: () => CoreTask;
}
export declare function getCppDepends(targetService: TargetTaskService): string[];
