import { FileSet } from '@ohos/hvigor';
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { CangjieCommonPath } from '../common/cangjie-common-path';
import { OhosHapTask } from '@ohos/hvigor-ohos-plugin/src/tasks/task/ohos-hap-task';
/**
 * move cangjie libs
 *
 * @since 2024/4/13
 */
export declare class MoveCangjieLibs extends OhosHapTask {
    private logger;
    constructor(taskService: TargetTaskService);
    declareInputFiles(): FileSet;
    declareOutputFiles(): FileSet;
    taskShouldDo(): boolean;
    initTaskDepends(): void;
    protected doTaskAction(): Promise<void>;
    protected moveHarBinLibs(cangjieCommonPath: CangjieCommonPath): Promise<void>;
}
