/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { AbstractCompileCangjie } from './abstract-compile-cangjie';
import { CangjieCommonPath } from '../common/cangjie-common-path';
import { CangjiePathImpl } from '../common/cangjie-path-impl';
/**
 * compile cangjie for idl task
 *
 * @since 2024/1/6
 */
export declare class CompileCangjieForIdl extends AbstractCompileCangjie {
    private ccfiLogger;
    constructor(taskService: TargetTaskService);
    protected doTaskAction(): Promise<void>;
    protected clearIdlFiles(cangjieCommonPath: CangjieCommonPath): void;
    /**
     * Copying Cangjie Compiled Products to the Target Directory
     * @protected
     */
    protected copyResultFile(cangjiePathImpl: CangjiePathImpl, dependsEnv: any, tomlName: string): Promise<void>;
    protected copyDemandLibsCommon(cangjiePathImpl: CangjiePathImpl, tomlName: string, moduleConfigTomlName: string): Promise<void>;
}
