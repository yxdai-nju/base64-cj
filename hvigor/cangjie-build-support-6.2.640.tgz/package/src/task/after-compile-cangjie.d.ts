import { FileSet, TaskInputValue } from '@ohos/hvigor';
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { BaseCangjieTask } from './base-cangjie-task';
/**
 * after compile cangjie
 *
 * @since 2024/4/13
 */
export declare class AfterCompileCangjie extends BaseCangjieTask {
    private logger;
    private readonly _moduleDir;
    constructor(taskService: TargetTaskService);
    taskShouldDo(): boolean;
    declareInputFiles(): FileSet;
    declareInputs(): Map<string, TaskInputValue>;
    initTaskDepends(): void;
    protected doTaskAction(): Promise<void>;
}
