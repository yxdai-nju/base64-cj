import { CangjieAdaptorErrorMessage, MatchFieldType } from './cangjie-types';
import { CangjieError } from './cangjie-error';
/**
 * hvigor的适配器
 */
export declare class CangjieErrorAdaptor {
    protected _hvigorError: CangjieError;
    constructor(value: any, field?: MatchFieldType);
    getErrorMessage(): CangjieAdaptorErrorMessage;
    getErrorCodeJsonPath(): string[];
    formatMessage(...args: unknown[]): this;
    formatSolutions(index: number, ...args: unknown[]): this;
}
