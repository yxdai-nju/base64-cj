import { OhosLogger } from '@ohos/hvigor-ohos-plugin/src/utils/log/ohos-logger';
import { CangjieAdaptorErrorMessage } from './cangjie-types';
import { CangjieErrorDetail } from './cangjie-error-info';
import { CangjieErrorAdaptor } from './cangjie-error-adaptor';
/**
 * cangjie日志的适配器
 *
 * @since 2025-03-15
 */
export declare class CangjieLogger extends OhosLogger {
    constructor(category?: string);
    /**
     * 获取对于类别的HvigorLogger实例
     *
     * @param {string} category 默认是default
     * @return {HvigorLogger}
     */
    static getLogger(category?: string): CangjieLogger;
    /**
     * 三段式打印错误信息(阻塞构建)
     * @param errorId 错误码表文件(如：hvigor.json)中的key
     * @param messages message格式化字符串
     * @param solutions solutions格式化字符串，二维数组，每一行对应solution中的一行
     */
    printErrorExit(errorId: string, messages?: unknown[], solutions?: unknown[][]): void;
    /**
     * 将传入的object对象 实例化成三段是
     * @param adaptorErrorMessage 不传description时，错误码描述信息按类别展示
     * @returns {string}
     */
    combinePhase(adaptorErrorMessage: CangjieAdaptorErrorMessage): string;
    /**
     * 从错误码截取错误归属码
     * @param {string} errorCode
     * @returns {string}
     */
    getErrorTypeCodeFromErrorCode(errorCode: string): string;
    /**
     * 将传入的object对象 实例化成HvigorErrorInfo
     * @param error
     * @returns
     */
    getRealError(error: any): CangjieErrorDetail;
    protected getCjAdaptor(errorId: string): CangjieErrorAdaptor;
    protected formatCjErrorAdaptor(errorId: string, messages?: unknown[], solutions?: unknown[][]): CangjieErrorAdaptor;
}
