/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */
export declare enum CompileAppTypeEnum {
    COMPILE_SDK_VER_LTE_21 = "COMPILE_SDK_VER_LTE_21",
    COMPATIBLE_SDK_VER_EQ_22 = "COMPATIBLE_SDK_VER_EQ_22",
    COMPATIBLE_SDK_VER_LT_22 = "COMPATIBLE_SDK_VER_LT_22",
    NORMAL_APP = "NORMAL_APP"
}
