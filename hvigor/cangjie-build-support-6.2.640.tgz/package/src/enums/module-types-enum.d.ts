/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import { OhosLogger } from '@ohos/hvigor-ohos-plugin/src/utils/log/ohos-logger';
import { CoreModuleModelImpl } from '@ohos/hvigor-ohos-plugin/src/model/module/core-module-model-impl';
export declare enum ModuleTypeEnum {
    HAP = "hap",
    HSP = "hsp",
    HAR = "har"
}
export declare function getModuleType(moduleModel: CoreModuleModelImpl): ModuleTypeEnum;
export declare function reportModuleTypeError(logger: OhosLogger): void;
